<?php
session_start();
require_once 'conexao.php'; // Arquivo de conexão com o banco de dados

// Verifica se o ID foi passado corretamente
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    // Obtém o caminho da foto antes de excluir a campanha
    $sql_foto = "SELECT foto FROM campanha WHERE Id = ?";
    $stmt_foto = $conn->prepare($sql_foto);
    
    if (!$stmt_foto) {
        die("Erro na preparação da consulta da foto: " . $conn->error);
    }

    $stmt_foto->bind_param("i", $id);
    $stmt_foto->execute();
    $resultado_foto = $stmt_foto->get_result();
    $campanha = $resultado_foto->fetch_assoc();

    // Exclui a foto do servidor, se existir
    if (!empty($campanha['foto']) && file_exists($campanha['foto'])) {
        unlink($campanha['foto']);
    }

    // Exclui a campanha do banco de dados
    $sql = "DELETE FROM campanha WHERE Id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Erro na preparação da consulta de exclusão: " . $conn->error);
    }

    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        // Redireciona para a página de campanhas com mensagem de sucesso
        header("Location: campanha.php?msg=Campanha+excluída+com+sucesso");
        exit();
    } else {
        echo "Erro ao excluir campanha: " . $stmt->error;
    }
} else {
    echo "ID inválido.";
}
?>


    if (!$stmt) {
        die("Erro na preparação da consulta de exclusão: " . $conn->error);
    }

    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('Campanha excluída com sucesso!'); window.location.href='Campanhas.php';</script>";
        exit();
    } else {
        die("Erro ao excluir campanha: " . $stmt->error);
    }
} else {
    die("ID inválido.");
}
?>
