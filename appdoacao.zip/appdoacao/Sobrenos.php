<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nós - Doe com Amor</title>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        :root {
            --bege-claro: #FFF5E1;
            --bege-secundario: #FFEBD1;
            --castanho: #8B5E3C;
            --castanho-escuro: #5C3B1E;
            --branco: #ffffff;
            --border-radius: 12px;
            --box-shadow: 0 8px 20px rgba(139, 94, 60, 0.3);
            --transition: all 0.3s ease-in-out;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--bege-claro), var(--branco));
            color: var(--castanho-escuro);
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            width: 100vw;
            min-height: 100vh;
            padding: 40px;
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .container {
            width: 90%;
            max-width: 1100px;
            background-color: var(--branco);
            padding: 50px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            text-align: center;
            border: 3px dashed var(--castanho);
        }

        h1 {
            color: var(--castanho);
            font-size: 40px;
            font-weight: 800;
            margin-bottom: 30px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        h2 {
            color: var(--castanho-escuro);
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 15px;
        }

        p {
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 25px;
        }

        .section {
            padding: 25px;
            background-color: var(--bege-secundario);
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            margin-bottom: 40px;
            text-align: left;
            border: 2px dashed var(--castanho);
            animation: fadeInSection 0.6s ease-in-out forwards;
        }

        @keyframes fadeInSection {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .contact-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
        }

        .contact {
            font-size: 20px;
            font-weight: 700;
            color: var(--castanho-escuro);
            display: flex;
            align-items: center;
            gap: 12px;
            background-color: var(--bege-claro);
            padding: 12px 20px;
            border-radius: var(--border-radius);
            border: 2px dashed var(--castanho);
            width: fit-content;
        }

        .contact i {
            font-size: 24px;
            color: var(--castanho);
        }

        .button {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(135deg, var(--castanho), var(--castanho-escuro));
            color: var(--branco);
            padding: 14px 22px;
            border-radius: var(--border-radius);
            text-decoration: none;
            font-size: 18px;
            font-weight: 700;
            transition: var(--transition);
            margin-top: 30px;
            box-shadow: 0 6px 14px rgba(139, 94, 60, 0.4);
        }

        .button i {
            font-size: 20px;
        }

        .button:hover {
            background: linear-gradient(135deg, var(--castanho-escuro), var(--castanho));
            transform: translateY(-4px);
            box-shadow: 0 10px 20px rgba(139, 94, 60, 0.5);
        }

        .highlight {
            font-weight: 700;
            color: var(--castanho);
        }

        .back-container {
            margin-top: 50px;
            text-align: center;
        }

        @media (max-width: 768px) {
            h1 {
                font-size: 32px;
            }

            h2 {
                font-size: 22px;
            }

            p {
                font-size: 16px;
            }

            .button {
                font-size: 16px;
                padding: 12px 18px;
            }

            .contact {
                font-size: 18px;
                padding: 10px 16px;
            }

            .contact i {
                font-size: 22px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Sobre Nós</h1>

    <div class="section">
        <h2>A Nossa Missão</h2>
        <p>Acreditamos que pequenos gestos podem transformar vidas. A nossa plataforma facilita a doação de bens materiais para crianças e famílias que precisam, promovendo a solidariedade e a partilha.</p>
    </div>

    <div class="section">
        <h2>Os Nossos Valores</h2>
        <p>Empatia, generosidade e compromisso com um mundo mais justo. Queremos criar uma rede de apoio onde todos possam ajudar e serem ajudados.</p>
    </div>

    <div class="section">
        <h2>Contacte-nos</h2>
        <div class="contact-container">
            <div class="contact"><i class="fas fa-phone-alt"></i> Telefone: <span class="highlight">935 711 307</span></div>
            <div class="contact"><i class="fas fa-envelope"></i> Email: <span class="highlight">contato@doecomamor.com</span></div>
        </div>
        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=contato@doecomamor.com" target="_blank" class="button">
            <i class="fas fa-paper-plane"></i> Enviar E-mail
        </a>
    </div>

    <div class="back-container">
        <a href="home.php" class="button"><i class="fas fa-arrow-left"></i> Voltar à Página Inicial</a>
    </div>
</div>

</body>
</html>




