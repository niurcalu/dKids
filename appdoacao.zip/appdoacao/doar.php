<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['utilizador_id']) || !isset($_GET['campanha_id'])) {
    header("Location: login.php");
    exit();
}

$utilizador_id = $_SESSION['utilizador_id'];
$campanha_id = intval($_GET['campanha_id']);
$mensagem = "";
$data = "";
$descricao = "";
$endereco = "";
$foto_path = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $descricao = $_POST['descricao'] ?? '';
    $endereco = $_POST['endereco'] ?? '';
    $data = date("Y-m-d");

    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === 0) {
        $nome_arquivo = time() . "_" . basename($_FILES["foto"]["name"]);
        $destino = "uploads/" . $nome_arquivo;
        move_uploaded_file($_FILES["foto"]["tmp_name"], $destino);
        $foto_path = $destino;
    }

    $stmt = $conn->prepare("INSERT INTO doacao (UtilizadorId, CampanhaId, Valor, Data, Endereco, foto) VALUES (?, ?, NULL, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("issss", $utilizador_id, $campanha_id, $data, $endereco, $foto_path);
        $stmt->execute();
        $mensagem = "✅ Doação registrada com sucesso!";
    } else {
        $mensagem = "Erro ao registrar doação: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Doar</title>
    <style>
        :root {
            --bege-claro: #F4E1C6;
            --castanho: #6D4C41;
            --castanho-escuro: #4B3621;
            --branco: #ffffff;
        }

        body {
            background-color: var(--bege-claro);
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            padding: 40px;
        }

        .form-wrapper {
            background-color: var(--branco);
            width: 100%;
            max-width: 700px;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(77, 54, 33, 0.15);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--castanho);
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            font-weight: 600;
            display: block;
            margin-bottom: 8px;
        }

        input[type="text"],
        input[type="file"],
        textarea {
            width: 100%;
            padding: 14px;
            border-radius: 8px;
            border: 1px solid #ccc;
            background-color: #fffaf7;
            font-size: 15px;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        button {
            background-color: var(--castanho);
            color: var(--branco);
            font-weight: bold;
            font-size: 16px;
            padding: 14px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: var(--castanho-escuro);
        }

        .mensagem {
            margin-top: 20px;
            text-align: center;
            color: green;
            font-weight: bold;
        }

        .recibo {
            margin-top: 30px;
            background-color: #fff8f2;
            padding: 25px;
            border-radius: 10px;
            border-left: 6px solid var(--castanho);
        }

        .recibo img {
            max-width: 150px;
            max-height: 150px;
            margin-top: 15px;
            border-radius: 8px;
        }

        .download-btn {
            margin-top: 15px;
            text-align: center;
        }

        .download-btn button {
            width: auto;
            padding: 10px 20px;
        }
    </style>
</head>
<body>
<div class="form-wrapper">
    <h2>Finalizar Doação</h2>

    <?php if ($mensagem): ?>
        <div class="mensagem"><?php echo $mensagem; ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="descricao">Mensagem (opcional):</label>
            <textarea name="descricao" id="descricao" placeholder="Deixe uma mensagem..."></textarea>
        </div>

        <div class="form-group">
            <label for="endereco">Endereço completo:</label>
            <input type="text" name="endereco" id="endereco" required placeholder="Rua, nº, bairro, cidade, país...">
        </div>

        <div class="form-group">
            <label for="foto">Comprovativo (opcional):</label>
            <input type="file" name="foto" id="foto" accept="image/*">
        </div>

        <button type="submit">Confirmar Doação</button>
    </form>

    <?php if ($mensagem && strpos($mensagem, "sucesso") !== false): ?>
        <div class="recibo" id="recibo">
            <h4>📄 Recibo de Doação</h4>
            <p><strong>Data:</strong> <?php echo date("d/m/Y", strtotime($data)); ?></p>
            <p><strong>Endereço:</strong> <?php echo htmlspecialchars($endereco); ?></p>
            <p><strong>Mensagem:</strong> <?php echo htmlspecialchars($descricao); ?></p>
            <?php if (!empty($foto_path)): ?>
                <p><strong>Comprovativo:</strong></p>
                <img src="<?php echo $foto_path; ?>" alt="Foto da Doação">
            <?php endif; ?>
        </div>
        <div class="download-btn">
            <button onclick="baixarPDF()">📥 Baixar Recibo em PDF</button>
        </div>
    <?php endif; ?>
</div>

<script>
    function baixarPDF() {
        const element = document.getElementById('recibo');
        const janela = window.open('', '', 'height=600,width=800');
        janela.document.write('<html><head><title>Recibo de Doação</title></head><body>');
        janela.document.write(element.outerHTML);
        janela.document.write('</body></html>');
        janela.document.close();
        janela.print();
    }
</script>
</body>
</html>







