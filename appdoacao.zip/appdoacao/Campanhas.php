<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['utilizador_id'])) {
    header("Location: login.php");
    exit();
}

$sql = "SELECT * FROM campanha ORDER BY DataInicio DESC";
$resultado = $conn->query($sql);
if (!$resultado) {
    die("Erro na consulta: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Campanhas de Doação</title>
    <style>
        :root{
            --bege:#F4E1C6;
            --cast:#6D4C41;
            --cast-dk:#4B3621;
            --white:#fff;
            --radius:12px;
        }
        *{box-sizing:border-box;margin:0;padding:0}
        body{
            font-family:'Segoe UI',sans-serif;
            background:var(--bege);
            color:var(--cast-dk);
            padding:32px 16px;
        }
        .container{
            max-width:1000px;
            margin:auto;
            background:var(--white);
            border-radius:var(--radius);
            box-shadow:0 8px 24px rgba(0,0,0,.08);
            padding:40px 32px 48px;
        }
        .header{
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
            gap:16px;
            margin-bottom:32px;
        }
        h2{color:var(--cast-dk)}
        .top-btn{
            text-decoration:none;
            background:var(--cast);
            color:var(--white);
            padding:10px 20px;
            border-radius:8px;
            font-weight:600;
            transition:.25s;
            min-width:160px;
            text-align:center;
        }
        .top-btn:hover{background:var(--cast-dk)}
        .campanha{
            display:flex;
            gap:20px;
            background:#fff8f0;
            border-radius:10px;
            padding:20px;
            margin-bottom:24px;
            box-shadow:0 4px 14px rgba(0,0,0,.05);
            transition:transform .2s;
        }
        .campanha:hover{transform:scale(1.015)}
        .campanha img{
            width:120px;height:120px;object-fit:cover;border-radius:8px;
        }
        .campanha-content{flex:1}
        .campanha-content h3{color:var(--cast);margin-bottom:6px}
        .descricao-campanha{font-size:15px;line-height:1.5;margin-bottom:14px}
        .botoes{
            display:flex;
            flex-wrap:wrap;
            gap:12px;
        }
        .botoes a{
            flex:1 1 140px;
            text-decoration:none;
            background:var(--cast);
            color:var(--white);
            padding:10px 16px;
            border-radius:6px;
            font-weight:600;
            text-align:center;
            transition:.25s;
        }
        .botoes a:hover{background:var(--cast-dk)}
        .empty{margin-top:40px;text-align:center;font-weight:bold;color:var(--cast)}
        @media(max-width:550px){
            .campanha{flex-direction:column;align-items:flex-start}
            .campanha img{width:100%;height:180px}
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h2>Campanhas de Doação</h2>
        <div class="top-actions">
            <a href="home.php" class="top-btn">Voltar</a>
            <a href="nova_campanha.php" class="top-btn">Adicionar Campanha</a>
        </div>
    </div>

    <?php if($resultado->num_rows>0){ while($c=$resultado->fetch_assoc()){ ?>
        <div class="campanha">
            <img src="<?= htmlspecialchars($c['foto']) ?>" alt="Imagem da campanha">
            <div class="campanha-content">
                <h3><?= htmlspecialchars($c['Nome']) ?></h3>
                <div class="descricao-campanha">
                    <?= $c['Descricao'] ?> <!-- sem htmlspecialchars aqui -->
                </div>
                <div class="botoes">
                    <a href="mensagem.php?campanha_id=<?= $c['Id'] ?>">Enviar Mensagem</a>
                    <a href="doar.php?campanha_id=<?= $c['Id'] ?>">Fazer Doação</a>
                    <a href="apagar_campanha.php?id=<?= $c['Id'] ?>"
                       onclick="return confirm('Tem certeza que deseja excluir esta campanha?');">Apagar</a>
                </div>
            </div>
        </div>
    <?php }}else{ ?>
        <p class="empty">Não há campanhas ativas no momento.</p>
    <?php } ?>
</div>
</body>
</html>






