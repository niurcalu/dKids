<?php
session_start();
require_once 'conexao.php';  // Arquivo de conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $palavra_passe = $_POST["palavra_passe"];
    $confirmar_palavra_passe = $_POST["confirmar_palavra_passe"];

    if ($palavra_passe !== $confirmar_palavra_passe) {
        $erro = "As palavras-passe não coincidem.";
    } else {
        $sql = "SELECT * FROM utilizador WHERE Email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $erro = "Este email já está registrado.";
        } else {
            $senha_hash = password_hash($palavra_passe, PASSWORD_DEFAULT);
            $sql = "INSERT INTO utilizador (Nome, Email, Senha) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $nome, $email, $senha_hash);

            if ($stmt->execute()) {
                header("Location: login.php");
                exit;
            } else {
                $erro = "Erro ao registrar o utilizador. Tente mais tarde.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Criar Conta</title>
    <style>
        * {
            box-sizing: border-box;
        }

        :root {
            --bege-claro: #F4E1C6;
            --castanho: #6D4C41;
            --castanho-escuro: #4B3621;
            --branco: #ffffff;
            --sombra: rgba(77, 51, 33, 0.2);
            --borda-radius: 10px;
            --transicao: all 0.3s ease;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--bege-claro);
            color: var(--castanho);
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .container {
            max-width: 450px;
            background-color: var(--branco);
            padding: 30px;
            border-radius: var(--borda-radius);
            box-shadow: 0 6px 12px var(--sombra);
        }

        h2 {
            color: var(--castanho);
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: bold;
        }

        input, button {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: var(--borda-radius);
            font-size: 16px;
        }

        input {
            border: 2px solid var(--castanho);
            background-color: var(--branco);
            transition: var(--transicao);
        }

        input:focus {
            border-color: var(--castanho-escuro);
            outline: none;
            box-shadow: 0 0 5px var(--sombra);
        }

        button {
            background-color: var(--castanho);
            color: var(--branco);
            border: none;
            cursor: pointer;
            font-weight: bold;
            transition: var(--transicao);
        }

        button:hover {
            background-color: var(--castanho-escuro);
            transform: translateY(-2px);
        }

        a {
            color: var(--castanho);
            text-decoration: none;
            font-size: 16px;
            margin-top: 15px;
            display: block;
            font-weight: bold;
            transition: var(--transicao);
        }

        a:hover {
            text-decoration: underline;
        }

        .error {
            color: red;
            font-weight: bold;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Criar Conta</h2>
        <?php if (isset($erro)) echo "<p class='error'>$erro</p>"; ?>
        <form method="POST">
            <input type="text" name="nome" placeholder="Nome" required><br>
            <input type="email" name="email" placeholder="E-mail" required><br>
            <input type="password" name="palavra_passe" placeholder="Palavra-passe" required><br>
            <input type="password" name="confirmar_palavra_passe" placeholder="Confirmar Palavra-passe" required><br>
            <button type="submit">Registrar</button>
        </form>
        <br>
        <a href="login.php">Já tenho uma conta. Fazer login.</a>
    </div>
</body>
</html>



