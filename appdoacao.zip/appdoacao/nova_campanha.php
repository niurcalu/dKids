<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nova Campanha</title>
  <!-- Incluindo o Quill -->
  <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
  <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
  <style>
    :root {
      --bege-claro: #F4E1C6; /* Bege mais visível */
      --castanho: #6D4C41; /* Castanho elegante */
      --castanho-escuro: #4B3621;
      --branco: #ffffff;
      --sombra: rgba(77, 51, 33, 0.2);
      --borda-radius: 8px;
      --transicao: all 0.3s ease;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: var(--bege-claro);
      color: var(--castanho);
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
      padding: 20px;
    }

    .container {
      width: 90%;
      max-width: 800px;
      background-color: var(--branco);
      padding: 25px;
      border-radius: var(--borda-radius);
      box-shadow: 0 5px 15px var(--sombra);
    }

    h2 {
      color: var(--castanho);
      font-size: 26px;
      margin-bottom: 20px;
      text-align: center;
    }

    .form-group {
      margin-bottom: 15px;
      text-align: left;
      width: 100%;
    }

    label {
      font-weight: bold;
      color: var(--castanho-escuro);
      display: block;
      margin-bottom: 5px;
    }

    input, textarea {
      width: 100%;
      padding: 10px;
      border: 2px solid var(--castanho);
      border-radius: var(--borda-radius);
      font-size: 16px;
      background-color: var(--branco);
      color: var(--castanho);
      transition: var(--transicao);
    }

    input:focus, textarea:focus {
      border-color: var(--castanho-escuro);
      outline: none;
      box-shadow: 0 0 5px var(--sombra);
    }

    .form-row {
      display: flex;
      gap: 15px;
      flex-wrap: wrap;
    }

    .form-row .form-group {
      flex: 1;
      min-width: 220px;
    }

    button {
      width: 100%;
      background-color: var(--castanho);
      color: var(--branco);
      border: none;
      padding: 12px;
      border-radius: var(--borda-radius);
      font-size: 18px;
      font-weight: bold;
      cursor: pointer;
      transition: var(--transicao);
      margin-top: 10px;
    }

    button:hover {
      background-color: var(--castanho-escuro);
      transform: translateY(-2px);
    }

    #editor {
      height: 200px;
      background-color: var(--branco);
      border: 2px solid var(--castanho);
      border-radius: var(--borda-radius);
      padding: 10px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Adicionar Nova Campanha</h2>
    <form action="salvar_campanha.php" method="POST" enctype="multipart/form-data">
      <div class="form-group">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required>
      </div>

      <div class="form-group">
        <label for="descricao">Descrição:</label>
        <div id="editor"></div>
        <input type="hidden" name="descricao" id="descricao">
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="data_inicio">Data de Início:</label>
          <input type="date" id="data_inicio" name="data_inicio" required>
        </div>

        <div class="form-group">
          <label for="data_fim">Data de Fim:</label>
          <input type="date" id="data_fim" name="data_fim" required>
        </div>
      </div>

      <div class="form-group">
        <label for="foto">Foto:</label>
        <input type="file" id="foto" name="foto" accept="image/*">
      </div>

      <button type="submit">Salvar Campanha</button>
    </form>
  </div>

  <script>
    var quill = new Quill('#editor', {
      theme: 'snow',
      placeholder: 'Digite a descrição da campanha...',
      modules: {
        toolbar: [
          [{ header: [1, 2, false] }],
          ['bold', 'italic', 'underline'],
          ['link', 'image'],
          [{ list: 'ordered' }, { list: 'bullet' }],
          ['clean']
        ]
      }
    });

    // Ao enviar o formulário, atualiza o valor do campo oculto com o conteúdo do editor
    document.querySelector('form').addEventListener('submit', function(e) {
      var descricao = document.querySelector('input[name=descricao]');
      descricao.value = quill.root.innerHTML;
    });
  </script>
</body>
</html>





