<?php
session_start();
require_once 'conexao.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Verifica se o e-mail existe
    $sql = "SELECT Id FROM utilizador WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $utilizador = $resultado->fetch_assoc();

    if ($utilizador) {
        // Gerar código de recuperação
        $codigo = rand(100000, 999999); 
        $_SESSION['codigo_recuperacao'] = $codigo;
        $_SESSION['email_recuperacao'] = $email;

        // Simulação de envio do código por e-mail (mostrar na tela)
        echo "Código enviado: <strong>$codigo</strong>";

        // Redirecionar para a página de verificação do código
        header("Location: confirmar.php");
        exit();
    } else {
        $erro = "E-mail não encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Recuperar Senha</title>
</head>
<body>
    <h2>Recuperar Senha</h2>
    <?php if (isset($erro)) echo "<p style='color: red;'>$erro</p>"; ?>
    <form method="POST">
        <label for="email">Digite seu e-mail:</label>
        <input type="email" id="email" name="email" required>
        <button type="submit">Enviar código</button>
    </form>
</body>
</html>
