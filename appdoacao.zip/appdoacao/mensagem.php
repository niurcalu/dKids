<?php
include 'conexao.php';

// IDs dos usuários
$remetente_id = isset($_POST['remetente_id']) ? $_POST['remetente_id'] : (isset($_GET['remetente_id']) ? $_GET['remetente_id'] : 1);
$destinatario_id = isset($_POST['destinatario_id']) ? $_POST['destinatario_id'] : (isset($_GET['destinatario_id']) ? $_GET['destinatario_id'] : 2);

// Envio de mensagem
if ($_SERVER["REQUEST_METHOD"] === "POST" && !empty($_POST['texto'])) {
    $texto = $_POST['texto'];

    $sql = "INSERT INTO mensagem (Texto, DataHora, RemetenteId, DestinatarioId)
            VALUES (?, NOW(), ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sii", $texto, $remetente_id, $destinatario_id);
    $stmt->execute();
    $stmt->close();
}

// Buscar histórico de mensagens
$sql = "SELECT * FROM mensagem
        WHERE (RemetenteId = ? AND DestinatarioId = ?)
           OR (RemetenteId = ? AND DestinatarioId = ?)
        ORDER BY DataHora ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iiii", $remetente_id, $destinatario_id, $destinatario_id, $remetente_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mensagens</title>
    <style>
        :root {
            --bege-claro: #F4E1C6;
            --castanho: #6D4C41;
            --castanho-escuro: #4B3621;
            --branco: #ffffff;
            --sombra: rgba(77, 51, 33, 0.2);
            --borda-radius: 12px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            background-color: var(--bege-claro);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .chat-container {
            width: 90%;
            max-width: 800px;
            height: 85vh;
            background-color: var(--branco);
            border-radius: var(--borda-radius);
            box-shadow: 0 6px 16px var(--sombra);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .chat-header {
            background-color: var(--castanho);
            color: var(--branco);
            padding: 20px;
            text-align: center;
            font-size: 22px;
            font-weight: bold;
        }

        .messages {
            flex-grow: 1;
            overflow-y: auto;
            padding: 20px;
            display: flex;
            flex-direction: column;
        }

        .message {
            max-width: 70%;
            padding: 12px 18px;
            margin: 10px;
            border-radius: var(--borda-radius);
            font-size: 16px;
            word-wrap: break-word;
        }

        .sent {
            background-color: var(--castanho);
            color: var(--branco);
            align-self: flex-end;
        }

        .received {
            background-color: var(--bege-claro);
            color: var(--castanho-escuro);
            align-self: flex-start;
        }

        .message strong {
            font-size: 12px;
            margin-bottom: 5px;
            display: block;
        }

        .chat-footer {
            display: flex;
            padding: 16px;
            background-color: #f0f0f0;
            border-top: 2px solid #ddd;
        }

        input[type="text"] {
            flex-grow: 1;
            padding: 14px;
            border: 2px solid var(--castanho);
            border-radius: var(--borda-radius);
            font-size: 15px;
            outline: none;
            transition: 0.3s ease-in-out;
        }

        input:focus {
            border-color: var(--castanho-escuro);
        }

        button {
            padding: 14px 20px;
            background-color: var(--castanho);
            color: var(--branco);
            border: none;
            border-radius: var(--borda-radius);
            cursor: pointer;
            font-size: 15px;
            margin-left: 10px;
            transition: 0.3s ease-in-out;
        }

        button:hover {
            background-color: var(--castanho-escuro);
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-header">Mensagens</div>
        <div class="messages">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="message <?= $row['RemetenteId'] == $remetente_id ? 'sent' : 'received' ?>">
                    <strong><?= $row['RemetenteId'] == $remetente_id ? 'Você' : 'Outro usuário' ?>:</strong>
                    <?= htmlspecialchars($row['Texto']) ?>
                </div>
            <?php endwhile; ?>
        </div>
        <div class="chat-footer">
            <form action="" method="post" style="display: flex; width: 100%;">
                <input type="hidden" name="remetente_id" value="<?= $remetente_id ?>">
                <input type="hidden" name="destinatario_id" value="<?= $destinatario_id ?>">
                <input type="text" name="texto" placeholder="Digite sua mensagem..." required>
                <button type="submit">Enviar</button>
            </form>
        </div>
    </div>
</body>
</html>

