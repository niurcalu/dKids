<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo_digitado = $_POST['codigo'];

    if ($codigo_digitado == $_SESSION['codigo_recuperacao']) {
        header("Location: nova.php");
        exit();
    } else {
        $erro = "Código incorreto.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Confirmar Código</title>
</head>
<body>
    <h2>Confirme o Código</h2>
    <?php if (isset($erro)) echo "<p style='color: red;'>$erro</p>"; ?>
    <form method="POST">
        <label for="codigo">Digite o código recebido:</label>
        <input type="text" id="codigo" name="codigo" required>
        <button type="submit">Confirmar</button>
    </form>
</body>
</html>
