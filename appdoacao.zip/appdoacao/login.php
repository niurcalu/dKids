<?php
session_start();
require_once 'conexao.php';

if (!$conn) {
    die("Erro de ligação à base de dados: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $palavra_passe = $_POST['palavra_passe'];

    $sql = "SELECT Id, nome, senha FROM utilizador WHERE email = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Erro na preparação da consulta: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $utilizador = $resultado->fetch_assoc();

    if ($utilizador && password_verify($palavra_passe, $utilizador['senha'])) {
        $_SESSION['utilizador_id'] = $utilizador['Id'];
        $_SESSION['utilizador_nome'] = $utilizador['nome'];
        header("Location: Campanhas.php");
        exit();
    } else {
        $erro = "E-mail ou palavra-passe incorretos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sessão</title>
    <style>
        :root {
            --bege-claro: #F4E1C6; /* Bege mais visível */
            --castanho: #6D4C41; /* Castanho elegante */
            --castanho-escuro: #4B3621; /* Castanho mais escuro */
            --branco: #ffffff;
            --sombra: rgba(77, 51, 33, 0.2);
            --borda-radius: 10px;
            --transicao: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--bege-claro);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-container {
            background-color: var(--branco);
            border-radius: var(--borda-radius);
            box-shadow: 0 8px 24px var(--sombra);
            padding: 35px;
            width: 100%;
            max-width: 420px;
        }

        h2 {
            color: var(--castanho);
            text-align: center;
            margin-bottom: 30px;
            font-size: 26px;
            font-weight: bold;
        }

        .error-message {
            color: #e74c3c;
            background-color: #FDEDED;
            padding: 12px;
            border-radius: var(--borda-radius);
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
            display: <?php echo isset($erro) ? 'block' : 'none'; ?>;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: var(--castanho-escuro);
            font-weight: bold;
            font-size: 14px;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 2px solid var(--castanho);
            border-radius: var(--borda-radius);
            font-size: 15px;
            transition: var(--transicao);
        }

        input:focus {
            border-color: var(--castanho-escuro);
            outline: none;
            box-shadow: 0 0 5px var(--sombra);
        }

        .btn-submit {
            width: 100%;
            padding: 12px;
            background-color: var(--castanho);
            color: var(--branco);
            border: none;
            border-radius: var(--borda-radius);
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: var(--transicao);
            margin-top: 10px;
        }

        .btn-submit:hover {
            background-color: var(--castanho-escuro);
            transform: translateY(-2px);
        }

        .links-container {
            display: flex;
            justify-content: space-between;
            margin-top: 24px;
            padding-top: 16px;
            border-top: 1px solid var(--castanho);
        }

        .link {
            color: var(--castanho);
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            transition: var(--transicao);
        }

        .link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Iniciar Sessão</h2>
        
        <div class="error-message">
            <?php if (isset($erro)) echo $erro; ?>
        </div>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="form-group">
                <label for="palavra_passe">Palavra-passe</label>
                <input type="password" id="palavra_passe" name="palavra_passe" required>
            </div>
            
            <button type="submit" class="btn-submit">Entrar</button>
        </form>
        
        <div class="links-container">
            <a href="recuperar.php" class="link">Esqueceu a senha?</a>
            <a href="Criar.php" class="link">Criar Conta</a>
        </div>
    </div>
</body>
</html>







