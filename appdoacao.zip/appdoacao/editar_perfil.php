<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['utilizador_id'])) {
    header("Location: login.php");
    exit();
}

$utilizadorId = $_SESSION['utilizador_id'];
$mensagem = "";

// Atualização
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $novaSenha = trim($_POST['nova_senha']);
    $confirmarSenha = trim($_POST['confirmar_senha']);

    // Atualiza nome e email
    $stmt = $conn->prepare("UPDATE utilizador SET nome = ?, email = ? WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("ssi", $nome, $email, $utilizadorId);
        $stmt->execute();
        $stmt->close();
    } else {
        die("Erro ao preparar statement (nome/email): " . $conn->error);
    }

    // Atualiza senha se fornecida
    if (!empty($novaSenha)) {
        if ($novaSenha === $confirmarSenha) {
            $senhaHash = password_hash($novaSenha, PASSWORD_DEFAULT);
            $stmtSenha = $conn->prepare("UPDATE utilizador SET senha = ? WHERE id = ?");
            if ($stmtSenha) {
                $stmtSenha->bind_param("si", $senhaHash, $utilizadorId);
                $stmtSenha->execute();
                $stmtSenha->close();
                $mensagem = "Perfil e senha atualizados com sucesso.";
            } else {
                die("Erro ao preparar statement (senha): " . $conn->error);
            }
        } else {
            $mensagem = "As senhas não coincidem.";
        }
    } else {
        $mensagem = "Perfil atualizado com sucesso.";
    }
}

// Buscar dados atuais
$stmt = $conn->prepare("SELECT nome, email FROM utilizador WHERE id = ?");
$stmt->bind_param("i", $utilizadorId);
$stmt->execute();
$stmt->bind_result($nomeAtual, $emailAtual);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil</title>
    <style>
        :root {
            --bege-claro: #F4E1C6;
            --castanho: #6D4C41;
            --castanho-escuro: #4B3621;
            --branco: #ffffff;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--bege-claro);
            color: var(--castanho-escuro);
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 60px auto;
            background-color: var(--branco);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: var(--castanho);
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            font-weight: bold;
            color: var(--castanho);
        }

        input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
            margin-top: 5px;
            font-size: 16px;
        }

        button {
            margin-top: 20px;
            padding: 12px;
            background-color: var(--castanho);
            color: var(--branco);
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s;
        }

        button:hover {
            background-color: var(--castanho-escuro);
        }

        .mensagem {
            margin-top: 15px;
            text-align: center;
            color: green;
            font-weight: bold;
        }

        .erro {
            margin-top: 15px;
            text-align: center;
            color: red;
            font-weight: bold;
        }

        .voltar {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: var(--castanho);
            text-decoration: none;
        }

        .voltar:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Editar Perfil</h2>

        <?php if (!empty($mensagem)) : ?>
            <p class="<?php echo strpos($mensagem, 'sucesso') !== false ? 'mensagem' : 'erro'; ?>">
                <?php echo htmlspecialchars($mensagem); ?>
            </p>
        <?php endif; ?>

        <form method="POST">
            <label for="nome">Nome</label>
            <input type="text" name="nome" id="nome" value="<?php echo htmlspecialchars($nomeAtual); ?>" required>

            <label for="email">Email</label>
            <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($emailAtual); ?>" required>

            <label for="nova_senha">Nova Palavra-Passe (opcional)</label>
            <input type="password" name="nova_senha" id="nova_senha">

            <label for="confirmar_senha">Confirmar Nova Palavra-Passe</label>
            <input type="password" name="confirmar_senha" id="confirmar_senha">

            <button type="submit">Salvar Alterações</button>
        </form>

        <a class="voltar" href="perfil.php">Voltar ao Perfil</a>
    </div>
</body>
</html>


