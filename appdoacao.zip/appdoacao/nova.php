<?php
session_start();
require_once 'conexao.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nova_senha = $_POST['nova_senha'];
    $confirmar_senha = $_POST['confirmar_senha'];

    if ($nova_senha !== $confirmar_senha) {
        $erro = "As senhas não coincidem.";
    } else {
        $senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);
        $email = $_SESSION['email_recuperacao'];

        $sql = "UPDATE utilizador SET senha = ? WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $senha_hash, $email);

        if ($stmt->execute()) {
            unset($_SESSION['codigo_recuperacao']);
            unset($_SESSION['email_recuperacao']);
            header("Location: login.php");
            exit();
        } else {
            $erro = "Erro ao atualizar a senha.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Nova Palavra-passe</title>
</head>
<body>
    <h2>Definir Nova Palavra-passe</h2>
    <?php if (isset($erro)) echo "<p style='color: red;'>$erro</p>"; ?>
    <form method="POST">
        <label for="nova_senha">Nova Palavra-passe:</label>
        <input type="password" id="palavra-passe" name="Palavra-passe" required>
        
        <label for="confirmar_senha">Confirmar nova senha:</label>
        <input type="password" id="confirmar_palavra-passe" name="Palavra-passe" required>
        
        <button type="submit">Alterar Senha</button>
    </form>
</body>
</html>
