<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['utilizador_id'])) {
    header("Location: login.php");
    exit();
}

$utilizadorId = $_SESSION['utilizador_id'];

// Buscar dados do utilizador
$stmt = $conn->prepare("SELECT nome, email FROM utilizador WHERE id = ?");
if (!$stmt) {
    die("Erro ao preparar statement do utilizador: " . $conn->error);
}
$stmt->bind_param("i", $utilizadorId);
$stmt->execute();
$result = $stmt->get_result();
$utilizador = $result->fetch_assoc();

// Gerar iniciais
function getIniciais($nome) {
    $partes = explode(' ', $nome);
    $iniciais = '';
    foreach ($partes as $p) {
        if (strlen($p) > 0) {
            $iniciais .= strtoupper($p[0]);
        }
    }
    return substr($iniciais, 0, 2);
}

// Buscar histórico de doações
$sqlDoacoes = "
    SELECT d.Valor, d.Data, d.foto, d.Endereco, c.Nome AS NomeCampanha
    FROM doacao d
    INNER JOIN campanha c ON d.CampanhaId = c.Id
    WHERE d.UtilizadorId = ?
    ORDER BY d.Data DESC
";
$stmtDoacoes = $conn->prepare($sqlDoacoes);
if (!$stmtDoacoes) {
    die("Erro ao preparar statement das doações: " . $conn->error);
}
$stmtDoacoes->bind_param("i", $utilizadorId);
$stmtDoacoes->execute();
$doacoes = $stmtDoacoes->get_result();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Meu Perfil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #F4E1C6;
            color: #4B3621;
            padding: 40px;
        }

        .perfil-container {
            max-width: 900px;
            margin: auto;
            background: #fff;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 8px 16px rgba(109, 76, 65, 0.3);
        }

        .info-usuario {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        .iniciais {
            width: 80px;
            height: 80px;
            background-color: #6D4C41;
            color: #fff;
            font-size: 32px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }

        .dados-usuario {
            flex-grow: 1;
        }

        .dados-usuario h2 {
            margin: 0;
            color: #6D4C41;
        }

        .dados-usuario a {
            font-size: 14px;
            color: #6D4C41;
            text-decoration: underline;
            margin-top: 6px;
            display: inline-block;
        }

        .tabela-doacoes {
            width: 100%;
            border-collapse: collapse;
        }

        .tabela-doacoes th, .tabela-doacoes td {
            border: 1px solid #DDD;
            padding: 12px;
            text-align: center;
        }

        .tabela-doacoes th {
            background-color: #F4E1C6;
            color: #4B3621;
        }

        .tabela-doacoes tr:nth-child(even) {
            background-color: #fdf6f0;
        }

        .voltar {
            margin-top: 30px;
            display: inline-block;
            padding: 12px 24px;
            background-color: #6D4C41;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            transition: background 0.3s;
        }

        .voltar:hover {
            background-color: #4B3621;
        }

        .foto-doacao {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 6px;
        }
    </style>
</head>
<body>

<div class="perfil-container">
    <div class="info-usuario">
        <div class="iniciais">
            <?php echo getIniciais($utilizador['nome']); ?>
        </div>
        <div class="dados-usuario">
            <h2><?php echo htmlspecialchars($utilizador['nome']); ?></h2>
            <p><?php echo htmlspecialchars($utilizador['email']); ?></p>
            <a href="editar_perfil.php">Editar perfil</a>
        </div>
    </div>

    <h3>Histórico de Doações</h3>

    <?php if ($doacoes->num_rows > 0) { ?>
        <table class="tabela-doacoes">
            <thead>
                <tr>
                    <th>Campanha</th>
                    <th>Valor</th>
                    <th>Data</th>
                    <th>Foto</th>
                    <th>Endereço</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($doacao = $doacoes->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($doacao['NomeCampanha']); ?></td>
                        <td><?php echo number_format($doacao['Valor'], 2); ?> MZN</td>
                        <td><?php echo date("d/m/Y", strtotime($doacao['Data'])); ?></td>
                        <td>
                            <?php if (!empty($doacao['foto'])) { ?>
                                <img src="<?php echo htmlspecialchars($doacao['foto']); ?>" alt="Foto doação" class="foto-doacao">
                            <?php } else { echo '-'; } ?>
                        </td>
                        <td><?php echo htmlspecialchars($doacao['Endereco']); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php } else { ?>
        <p>Nenhuma doação registrada.</p>
    <?php } ?>

    <a href="campanhas.php" class="voltar">← Voltar para Campanhas</a>
</div>

</body>
</html>


