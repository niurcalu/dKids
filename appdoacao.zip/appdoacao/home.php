<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['utilizador_id'])) {
    header("Location: login.php");
    exit;
}

$utilizador_id = $_SESSION['utilizador_id'];
$sql = "SELECT Nome FROM utilizador WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $utilizador_id);
$stmt->execute();
$resultado = $stmt->get_result();
$utilizador = $resultado->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>DoaKids - Painel Principal</title>

  <!-- Lucide Icons -->
  <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>

  <style>
    :root {
      --bege-claro: #F4E1C6;
      --castanho: #6D4C41;
      --castanho-escuro: #4B3621;
      --branco: #ffffff;
      --sombra: rgba(77, 51, 33, 0.2);
      --borda-radius: 12px;
      --transicao: all 0.3s ease;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
      display: flex;
      height: 100vh;
      background-color: var(--bege-claro);
      color: var(--castanho);
    }

    .sidebar {
      width: 260px;
      background-color: var(--castanho);
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 80px 20px;
      box-shadow: 2px 0 10px var(--sombra);
    }

    .sidebar h2 {
      margin-bottom: 40px;
      color: var(--branco);
      font-size: 1.8rem;
    }

    .nav-menu {
      list-style: none;
      width: 100%;
    }

    .nav-menu li {
      margin-bottom: 15px;
    }

    .nav-menu a {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px;
      background-color: var(--castanho-escuro);
      color: var(--branco);
      text-decoration: none;
      border-radius: var(--borda-radius);
      font-weight: bold;
      transition: var(--transicao);
    }

    .nav-menu a:hover {
      background-color: var(--bege-claro);
      color: var(--castanho-escuro);
    }

    .main-content {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    .container {
      background-color: var(--branco);
      border-radius: var(--borda-radius);
      padding: 50px;
      max-width: 650px;
      width: 100%;
      text-align: center;
      box-shadow: 0 10px 30px var(--sombra);
    }

    .container header {
      font-size: 2rem;
      color: var(--castanho);
      margin-bottom: 20px;
      font-weight: bold;
    }

    .welcome-message {
      font-size: 1.3rem;
      color: var(--castanho-escuro);
      margin-bottom: 30px;
    }

    .action-button {
      display: inline-flex;
      align-items: center;
      gap: 12px;
      padding: 14px 36px;
      font-size: 1.1rem;
      font-weight: bold;
      border-radius: var(--borda-radius);
      text-decoration: none;
      transition: var(--transicao);
    }

    .donate-button {
      background: linear-gradient(135deg, #D9475A, #B23A48);
      color: var(--branco);
      box-shadow: 0 4px 12px rgba(217, 71, 90, 0.4);
    }

    .donate-button:hover {
      transform: translateY(-2px);
    }

    .logout-link {
      background-color: transparent;
      color: #B23A48;
      border: 2px solid #B23A48;
    }

    .logout-link:hover {
      background-color: #B23A48;
      color: var(--branco);
    }

    .assistant-button {
      background-color: var(--bege-claro);
      color: var(--castanho-escuro);
      border: 2px solid var(--castanho-escuro);
    }

    .assistant-button:hover {
      background-color: var(--castanho-escuro);
      color: var(--branco);
    }

    @media (max-width: 768px) {
      body {
        flex-direction: column;
      }

      .sidebar {
        width: 100%;
        flex-direction: row;
        justify-content: center;
        padding: 20px;
      }

      .nav-menu {
        display: flex;
        gap: 10px;
      }
    }
  </style>
</head>
<body>

  <div class="sidebar">
    <h2>Menu</h2>
    <ul class="nav-menu">
      <li><a href="home.php"><i data-lucide="home"></i>Início</a></li>
      <li><a href="campanhas.php"><i data-lucide="megaphone"></i>Campanhas</a></li>
      <li><a href="feedback.php"><i data-lucide="message-circle"></i>Feedback</a></li>
      <li><a href="perfil.php"><i data-lucide="user"></i>Perfil</a></li>
      <li><a href="sobrenos.php"><i data-lucide="info"></i>Sobre Nós</a></li>
      <li><a href="assistente.php" class="assistant-button"><i data-lucide="help-circle"></i>Assistente Virtual</a></li>
    </ul>
  </div>

  <div class="main-content">
    <div class="container">
      <header>DoaKids</header>
      <p class="welcome-message">Bem-vindo(a), <?= htmlspecialchars($utilizador['Nome']) ?>!<br>Fazer o bem faz bem. Junte-se a nós para transformar vidas com pequenos gestos.</p>
      <a href="doar.php" class="action-button donate-button"><i data-lucide="heart"></i>Doar Agora</a>
      <a href="logout.php" class="action-button logout-link"><i data-lucide="log-out"></i>Sair</a>
    </div>
  </div>

  <script>
    lucide.createIcons();
  </script>

</body>
</html>


