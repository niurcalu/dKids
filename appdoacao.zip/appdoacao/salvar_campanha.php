<?php
session_start();
require_once 'conexao.php'; 


if (!$conn) {
    die("Erro de conexão com o banco de dados: " . mysqli_connect_error());
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $data_inicio = $_POST['data_inicio'];
    $data_fim = $_POST['data_fim'];

    
    $foto = "";
    if (!empty($_FILES['foto']['name'])) {
        $foto_nome = time() . "_" . basename($_FILES['foto']['name']);
        $foto_caminho = "uploads/" . $foto_nome;

        
        if (!is_dir("uploads")) {
            mkdir("uploads", 0777, true);
        }

        
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $foto_caminho)) {
            $foto = $foto_caminho;
        } else {
            die("Erro ao salvar a imagem.");
        }
    }

    $sql = "INSERT INTO campanha (Nome, Descricao, DataInicio, DataFim, foto) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Erro na preparação da consulta: " . $conn->error);
    }

    $stmt->bind_param("sssss", $nome, $descricao, $data_inicio, $data_fim, $foto);

    if ($stmt->execute()) {
       
        header("Location: Campanhas.php");
        exit();
    } else {
        die("Erro ao salvar campanha: " . $stmt->error);
    }
} else {
    die("Acesso inválido.");
}
?>
